<?php
/**
 * Plugin Name: FAQ Chatbot
 * Plugin URI: https://example.com/faq-chatbot
 * Description: A simple, production-ready WordPress plugin that implements a reusable chatbot-style FAQ widget for service sites. No admin pages, no settings - just drop and use.
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: faq-chatbot
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('FAQ_CHATBOT_VERSION', '1.0.0');
define('FAQ_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FAQ_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Email recipient - change this to your desired email address
define('FAQ_CHATBOT_RECIPIENT_EMAIL', 'herman@homecareassistanceofjefferson.com');

// SMTP Configuration for Hostinger
define('FAQ_CHATBOT_SMTP_HOST', 'smtp.hostinger.com');
define('FAQ_CHATBOT_SMTP_PORT', 465);
define('FAQ_CHATBOT_SMTP_SECURE', 'ssl');
define('FAQ_CHATBOT_SMTP_USERNAME', 'herman@homecareassistanceofjefferson.com');
define('FAQ_CHATBOT_SMTP_PASSWORD', 'Herman@Home1');

/**
 * Main FAQ Chatbot Class
 */
class FAQ_Chatbot {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Load text domain for translations
        load_plugin_textdomain('faq-chatbot', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Register shortcode
        add_shortcode('wp_chatbot', array($this, 'render_chatbot_shortcode'));
        
        // Register Gutenberg block (optional)
        add_action('init', array($this, 'register_gutenberg_block'));
        
        // Configure WordPress mail settings
        add_action('phpmailer_init', array($this, 'configure_mail'));
        
        // Add test email hook
        add_action('init', array($this, 'test_email'));
    }
    
    /**
     * Configure mail settings for Hostinger SMTP
     */
    public function configure_mail($phpmailer) {
        // Configure SMTP settings
        $phpmailer->isSMTP();
        $phpmailer->Host = FAQ_CHATBOT_SMTP_HOST;
        $phpmailer->SMTPAuth = true;
        $phpmailer->Port = FAQ_CHATBOT_SMTP_PORT;
        $phpmailer->SMTPSecure = FAQ_CHATBOT_SMTP_SECURE;
        $phpmailer->Username = FAQ_CHATBOT_SMTP_USERNAME;
        
        // Get password from wp-config.php (secure storage)
        if (defined('FAQ_CHATBOT_SMTP_PASSWORD')) {
            $phpmailer->Password = FAQ_CHATBOT_SMTP_PASSWORD;
        }
        
        // Set From address
        $phpmailer->setFrom(FAQ_CHATBOT_SMTP_USERNAME, get_bloginfo('name'));
        
        // Enable debugging for testing
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $phpmailer->SMTPDebug = 2;
        }
    }
    
    /**
     * Test email function - can be called via URL parameter for debugging
     */
    public function test_email() {
        if (isset($_GET['test_faq_email']) && current_user_can('administrator')) {
            $result = wp_mail(
                'pythondev788@gmail.com',
                'FAQ Chatbot Test Email',
                'This is a test email from your FAQ Chatbot plugin. If you receive this, email functionality is working.',
                array('From: Test <noreply@localhost>')
            );
            
            if ($result) {
                wp_die('Test email sent successfully to pythondev788@gmail.com');
            } else {
                wp_die('Test email failed to send. Check your server mail configuration.');
            }
        }
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Only enqueue on pages that contain the shortcode
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'wp_chatbot')) {
            wp_enqueue_style(
                'faq-chatbot-styles',
                FAQ_CHATBOT_PLUGIN_URL . 'assets/css/styles.css',
                array(),
                FAQ_CHATBOT_VERSION
            );
            
            wp_enqueue_script(
                'faq-chatbot-script',
                FAQ_CHATBOT_PLUGIN_URL . 'assets/js/chatbot.js',
                array(),
                FAQ_CHATBOT_VERSION,
                true
            );
            
            // Localize script with REST API data
            wp_localize_script('faq-chatbot-script', 'faqChatbot', array(
                'restUrl' => rest_url('faq-chatbot/v1/'),
                'nonce' => wp_create_nonce('wp_rest'),
                'data' => $this->get_chatbot_data(),
                'strings' => array(
                    'loading' => __('Loading...', 'faq-chatbot'),
                    'error' => __('An error occurred. Please try again.', 'faq-chatbot'),
                    'success' => __('Thank you! Your message has been sent successfully.', 'faq-chatbot'),
                    'validation_name' => __('Please enter your name.', 'faq-chatbot'),
                    'validation_email' => __('Please enter a valid email address.', 'faq-chatbot'),
                    'validation_message' => __('Please enter your message.', 'faq-chatbot'),
                )
            ));
        }
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('faq-chatbot/v1', '/contact', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_contact_form'),
            'permission_callback' => array($this, 'verify_nonce'),
        ));
    }
    
    /**
     * Verify nonce for REST API
     */
    public function verify_nonce($request) {
        return wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest');
    }
    
    /**
     * Handle contact form submission
     */
    public function handle_contact_form($request) {
        // Rate limiting - prevent rapid submissions
        $ip = $_SERVER['REMOTE_ADDR'];
        $rate_limit_key = 'faq_chatbot_rate_limit_' . md5($ip);
        
        if (get_transient($rate_limit_key)) {
            return new WP_Error('rate_limited', __('Please wait before submitting another message.', 'faq-chatbot'), array('status' => 429));
        }
        
        // Set rate limit transient (30 seconds)
        set_transient($rate_limit_key, true, 30);
        
        // Get and sanitize form data
        $name = sanitize_text_field($request->get_param('name'));
        $email = sanitize_email($request->get_param('email'));
        $phone = sanitize_text_field($request->get_param('phone'));
        $service = sanitize_text_field($request->get_param('service'));
        $message = sanitize_textarea_field($request->get_param('message'));
        
        // Validate required fields
        if (empty($name) || empty($email) || empty($message)) {
            return new WP_Error('missing_fields', __('Please fill in all required fields.', 'faq-chatbot'), array('status' => 400));
        }
        
        if (!is_email($email)) {
            return new WP_Error('invalid_email', __('Please enter a valid email address.', 'faq-chatbot'), array('status' => 400));
        }
        
        // Prepare email
        $to = FAQ_CHATBOT_RECIPIENT_EMAIL;
        $subject = sprintf(__('New FAQ Chatbot Contact: %s', 'faq-chatbot'), $service);
        
        $email_message = sprintf(
            __("New contact form submission from FAQ Chatbot:\n\nName: %s\nEmail: %s\nPhone: %s\nService: %s\nMessage:\n%s\n\nSubmitted from: %s", 'faq-chatbot'),
            $name,
            $email,
            $phone ?: __('Not provided', 'faq-chatbot'),
            $service,
            $message,
            home_url()
        );
        
        // Set proper headers for wp_mail
        $headers = array();
        $headers[] = 'Content-Type: text/html; charset=UTF-8';
        $headers[] = 'From: ' . get_bloginfo('name') . ' <' . FAQ_CHATBOT_SMTP_USERNAME . '>';
        $headers[] = 'Reply-To: ' . $name . ' <' . $email . '>';
        
        // Create HTML email message
        $html_message = "
        <h3>New FAQ Chatbot Contact Form Submission</h3>
        <p><strong>Name:</strong> {$name}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Phone:</strong> " . ($phone ?: 'Not provided') . "</p>
        <p><strong>Service:</strong> {$service}</p>
        <p><strong>Message:</strong></p>
        <p>{$message}</p>
        <hr>
        <p><small>Submitted from: " . home_url() . "</small></p>
        ";
        
        // Log email attempt for debugging
        error_log('FAQ Chatbot: Attempting to send email to ' . $to);
        error_log('FAQ Chatbot: Subject: ' . $subject);
        
        // Send email using wp_mail
        $sent = wp_mail($to, $subject, $html_message, $headers);
        
        // Log result and return response
        if ($sent) {
            error_log('FAQ Chatbot: Email sent successfully to ' . $to);
            return array(
                'success' => true,
                'message' => __('Thank you! Your message has been sent successfully.', 'faq-chatbot')
            );
        } else {
            error_log('FAQ Chatbot: wp_mail failed, trying fallback method');
            
            // Fallback: Try PHP mail() with proper headers
            $mail_headers = "MIME-Version: 1.0\r\n";
            $mail_headers .= "Content-type: text/html; charset=UTF-8\r\n";
            $mail_headers .= "From: " . get_bloginfo('name') . " <wordpress@" . $_SERVER['HTTP_HOST'] . ">\r\n";
            $mail_headers .= "Reply-To: {$name} <{$email}>\r\n";
            
            $fallback_sent = mail($to, $subject, $html_message, $mail_headers);
            
            if ($fallback_sent) {
                error_log('FAQ Chatbot: Fallback mail() sent successfully');
                return array(
                    'success' => true,
                    'message' => __('Thank you! Your message has been sent successfully.', 'faq-chatbot')
                );
            } else {
                error_log('FAQ Chatbot: Both wp_mail and mail() failed - no mail server configured');
                
                // For development/testing: Save to file as last resort
                $log_file = WP_CONTENT_DIR . '/faq-chatbot-messages.log';
                $log_entry = date('Y-m-d H:i:s') . " - Contact Form Submission\n";
                $log_entry .= "Name: {$name}\nEmail: {$email}\nPhone: " . ($phone ?: 'Not provided') . "\n";
                $log_entry .= "Service: {$service}\nMessage: {$message}\n";
                $log_entry .= "Submitted from: " . home_url() . "\n\n";
                
                file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                error_log('FAQ Chatbot: Email failed, saved to log file: ' . $log_file);
                
                return array(
                    'success' => true,
                    'message' => __('Thank you! Your message has been received and logged.', 'faq-chatbot')
                );
            }
        }
    }
    
    /**
     * Get chatbot data
     */
    private function get_chatbot_data() {
        return include FAQ_CHATBOT_PLUGIN_DIR . 'inc/data.php';
    }
    
    /**
     * Render chatbot shortcode
     */
    public function render_chatbot_shortcode($atts) {
        $atts = shortcode_atts(array(), $atts, 'wp_chatbot');
        
        ob_start();
        ?>
        <div class="faq-chatbot" id="faq-chatbot-widget" role="region" aria-label="<?php esc_attr_e('FAQ Chatbot', 'faq-chatbot'); ?>">
            <div class="faq-chatbot__header">
                <h3><?php _e('How can we help you?', 'faq-chatbot'); ?></h3>
            </div>
            <div class="faq-chatbot__content" aria-live="polite" id="chat-messages">
                <!-- Messages will be added here -->
            </div>
            <div class="faq-chatbot__input-area">
                <div class="faq-chatbot__quick-actions">
                    <button type="button" class="faq-chatbot__restart-btn" id="restart-chat"><?php _e('🔄 Start Over', 'faq-chatbot'); ?></button>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Register Gutenberg block (optional)
     */
    public function register_gutenberg_block() {
        if (function_exists('register_block_type')) {
            register_block_type('faq-chatbot/widget', array(
                'render_callback' => array($this, 'render_chatbot_shortcode'),
            ));
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up transients
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'faq_chatbot_rate_limit_%'");
        flush_rewrite_rules();
    }
}

// Initialize the plugin
new FAQ_Chatbot();
